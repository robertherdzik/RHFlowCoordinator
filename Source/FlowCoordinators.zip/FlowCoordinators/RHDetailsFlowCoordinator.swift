//
//  Created by Robert on 08/07/16.
//  Copyright © 2016 Robert. All rights reserved.
//

import UIKit

class RHDetailsFlowCoordinator: RHBaseFlowCoordinator, RHFlowControllerStartProtocol {

    private var detailModalPresenter: RHDetailModalPresenter?
    
    func start() {
        detailModalPresenter = RHDetailModalPresenter()
        detailModalPresenter?.present(on: navController)
        detailModalPresenter?.dismissCallback = { [weak self] in
            guard let sSelf = self else { return }
            
            sSelf.delegate?.workDone(withCoordinator: sSelf)
        }
    }
}

extension RHDetailsFlowCoordinator: RHDetailsViewControllerDelegate {
    
}

protocol RHModalPresenterProtocol {
    var dismissCallback: (()->())? { get set }
    func present(on navController: RHCustomNavigationController?)
}

class RHDetailModalPresenter: RHObjectDebug, RHModalPresenterProtocol {
    
    private var detailsVC: RHDetailsViewController?
    var dismissCallback: (()->())?
    
    func present(on navController: RHCustomNavigationController?) {
        guard let navController = navController,
            let presenterVC = navController.viewControllers.last else { return }
        
        detailsVC = RHDetailsViewController()
        let leftButton = UIBarButtonItem(barButtonSystemItem: .Cancel,
                                         target: self,
                                         action: #selector(cancelTapped))
        detailsVC!.navigationItem.leftBarButtonItem = leftButton
        detailsVC!.title = "details"
        
        let modalNavigationController = RHCustomNavigationController(rootViewController: detailsVC!)
        presenterVC.presentViewController(modalNavigationController,
                                          animated: true,
                                          completion: nil)
    }
    
    @objc func cancelTapped() {
        detailsVC?.dismissViewControllerAnimated(true) { [weak self] in
            self?.dismissCallback?()
        }
    }
}